#include <stdio.h>

int main() {
    printf("B24110106075\n");
    return 0;
}
